# # CodeIgniter 4 Admin 
## What is CodeIgniter Admin?
Codegniter admin is simple admin panel power by AdminLTE3 
This project was created base on tutorials by Alex Lancer.
> https://www.youtube.com/channel/UCIbtEs1nrFY14bgD_ake7HA
Please do support him as he is doing a great job to teach with his precious time.


## 1. Clone the project XAMPP/WAMP directory
composer install
## 2. Create a database in you phpMyAdmin 
Import the example.sql file from public/example.sql
You can modify the table as per your need as this is only a starting point

## 3. Setup your .env file

## 4. login 
Email: test@gmail.com

Password:1234qwer


## Contributing
Thank you for considering contributing to CodeIgniter Admin. 

## Feed back
Please sent feedback @ pemarekdendoree@gmail.com




